//Class Saque represents an ATM withdrawal transaction

public class Saque extends Transacao {
	private int montante;
	private Teclado keypad;
	private CashDispenser cashDispenser;
	
	private final static int CANCELADO = 6;
	
	public Saque(int userAccountNumber, Tela atmScreen, BankDatabase atmBankDatabase, Teclado atmKeypad, CashDispenser atmCashDispenser) {
		super(userAccountNumber, atmScreen, atmBankDatabase);
		
		keypad = atmKeypad;
		cashDispenser = atmCashDispenser;
	}
	
	@Override
	public void execute() {
		boolean cashDispensed = false;
		double availableBalance;
		
		BankDatabase bankDatabase = getBankDatabase();
		Tela screen = getScreen();
		
		do {

			montante = displayMenuOfAmounts();
			

			if (montante != CANCELADO) {

				availableBalance = bankDatabase.getSaldoDisponivel(getAccountNumber());
				
				if (montante <= availableBalance) {
					if (cashDispenser.isSufficientCashAvailable(montante)) {
						bankDatabase.debito(getAccountNumber(), montante);
						
						cashDispenser.dispenseCash(montante);
						cashDispensed = true;
						
						screen.displayLinhaMensagem("\nYour cash has been" + " dispensed. Please take your cash now.");
					}
					else {
						screen.displayLinhaMensagem("\nInsufficient cash available in the ATM." + "\n\nPlease choose a smaller amount.");
					}
				}
					else {
						screen.displayLinhaMensagem("\nInsufficient funds in your account." + "\n\nPlease choose a smaller amount.");
					}
				}
				else {
					screen.displayLinhaMensagem("\nCanceling transaction...");
					return;
				}
			} while (!cashDispensed);
		}
		
		private int displayMenuOfAmounts() {
			int userChoice = 0;
			
			Tela screen = getScreen();
			
			int[] amounts = {0, 20, 40, 60, 100, 200};
			
			while (userChoice == 0) {

				screen.displayLinhaMensagem("\nOpcoes de Saque:");
				screen.displayLinhaMensagem("1 - $20");
				screen.displayLinhaMensagem("2 - $40");
				screen.displayLinhaMensagem("3 - $60");
				screen.displayLinhaMensagem("4 - $100");
				screen.displayLinhaMensagem("5 - $200");
				screen.displayLinhaMensagem("6 - Cancelar Transacao");
				screen.displayLinhaMensagem("\nEscolha um valor para o saque: ");
				
				int input = keypad.getInput();
				
				switch (input) {
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
					userChoice = amounts[input];
					break;
				case CANCELADO:
					userChoice = CANCELADO;
					break;
				default: 
					screen.displayMensagem("\nOpcao INVALIDA. Tenta Novamente. ");
				}
			}
			return userChoice;	
		}		
}