// Conta.java
// Represents a bank account

public class Conta {
	private int numeroConta; // acc number
	private int pin; // pin number
	private double saldoDisponivel; // balance which is currently available
	private double saldoTotal; // total funding + pending deposits
	
	//Conta constructor initializes attributes
	public Conta(int ContaNumero, int Pin, double SaldoDisponivel, double SaldoTotal) {
		numeroConta = ContaNumero;
		pin = Pin;
		saldoDisponivel = SaldoDisponivel;
		saldoTotal = SaldoTotal;
	} // end of the constructor
	
	// validate users pin
	public boolean validaPIN (int usuarioPIN) {
		if (pin == usuarioPIN)
			return true;
		else
			return false;
	}
	
	public double getSaldoDisponivel(){
		return saldoDisponivel;
	}
	
	public double getTotalSaldo() {
		return saldoTotal;
	}
	
	public int getNumeroConta() {
		return numeroConta;
	}
	
	public void credito(double valor) {
		saldoTotal += valor;
	}
	
	public void debito(double valor) {
		saldoDisponivel -= valor;
		saldoTotal -= valor;
	}
}
