
public class BankDatabase {
	private Conta[] contas;
	

	public BankDatabase() {
		contas = new Conta[2]; // test accounts
		contas[0] = new Conta(12345, 54321, 1000.0, 1200.0);
		contas[1] = new Conta(98765, 56789, 200.0, 200.0);
	}
	
	private Conta getConta(int numeroConta) {
		for (Conta contaAtual : contas) {
				if (contaAtual.getNumeroConta() == numeroConta)
					return contaAtual;
				}
			return null;
		}
	
	public boolean usuarioAutenticado(int numeroContaUsuario, int usuarioPin) {
		Conta usuarioConta = getConta(numeroContaUsuario);
		
		if (usuarioConta != null) {
			return usuarioConta.validaPIN(usuarioPin);
		} else {
			return false;
		}
	}
	
	public double getSaldoDisponivel(int numeroContaUsuario) {
		return getConta(numeroContaUsuario).getSaldoDisponivel();
	}
	
	public double getSaldoTotal(int numeroContaUsuario) {
		return getConta(numeroContaUsuario).getSaldoDisponivel();
	}
	
	// credit an amount from the account with specified accout number
	public void credito(int numeroContaUsuario, double montante) {
		getConta(numeroContaUsuario).credito(montante);
	}
	
	// debit an amount from account with specified account number
	public void debito(int numeroContaUsuario, double montante) {
		getConta(numeroContaUsuario).debito(montante);
	}
}
