//Deposito.java

public class Deposito extends Transacao {
	private double montante;
	private Teclado keypad;
	private DepositSlot depositSlot;
	private final static int CANCELADO = 0;
	
	public Deposito(int userAccountNumber, Tela atmScreen, BankDatabase atmBankDatabase, Teclado atmKeypad, DepositSlot atmDepositSlot) {
		super (userAccountNumber, atmScreen, atmBankDatabase);
		
		keypad = atmKeypad;
		depositSlot = atmDepositSlot;
	}
	
	@Override
	public void execute() {
		BankDatabase bankDatabase = getBankDatabase();
		Tela screen = getScreen();
		
		montante = promptForDepositAmount();
		
		if (montante != CANCELADO) {

			screen.displayMensagem("\nFavor inserir o envelope contendo o deposito ");
			screen.displayMontante(montante);
			screen.displayLinhaMensagem(".");
			
			boolean envelopeReceived = depositSlot.isEnvelopeReceived();
			
			if (envelopeReceived) {
				screen.displayMensagem("\nSeu envelope j� foi" + " recebido.\nATEN��O: O montante que voce acabou de depositar n�o estar� dispon�vel at� que verifiquemos os valores em especie e cheques contidods no envelope.");
				bankDatabase.credito(getAccountNumber(), montante);
			} else {
				screen.displayLinhaMensagem("\nVoc� n�o inseriu um envelope, assim sendo o ATM cancelou sua transa��o.");
			}
		} else {
			screen.displayLinhaMensagem("\nCancelando a Transa��o...");
		}
	}
	
	private double promptForDepositAmount() {
		Tela screen = getScreen();
		
		screen.displayMensagem("\nPor favor insira o valor do dep�sito (ou 0 para cancelar");
		int input = keypad.getInput();
		
		if (input == CANCELADO) 
			return CANCELADO;
		else {
			return (double) input / 100;
		}
	}
}
