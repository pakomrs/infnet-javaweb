//DepositSlot.java

public class DepositSlot {
	// O coletor de deposito ser� sempre TRUE por estarmos somente simulando o processo
	public boolean isEnvelopeReceived() {
		return true;
	}
}
