// Super classe Abstrata

public abstract class Transacao {
	private int accountNumber;
	private Tela screen;
	private BankDatabase bankDatabase;
	
	public Transacao(int userAccountNumber, Tela atmScreen, BankDatabase atmBankDatabase) {
		accountNumber = userAccountNumber;
		screen = atmScreen;
		bankDatabase = atmBankDatabase;
	}
	
	public int getAccountNumber() {
		return accountNumber;
	}
	
	public Tela getScreen() {
		return screen;
	}
	
	public BankDatabase getBankDatabase() {
		return bankDatabase;
	}
	
	abstract public void execute();
}
